# Validación de 41 puntos: avances conservados

Comparación de monopolio, dos sellers y tres sellers mediante OE marginal,
con `p0 = {0.1, 0.3, 0.5, 0.7, 0.8, 0.9}` y
`rho = {0.6, 0.7, 0.8, 0.9}`.

Esta validación global de 21, 31 y 41 puntos se detuvo por su costo computacional.
Sus 57 resultados certificados se conservan. El barrido inicial con los mismos
24 pares de parámetros continúa con 21 y 31 puntos en
[rho_p0_sweep_31](../rho_p0_sweep_31/README.md).

- [Estado del barrido](../../data/rho_p0_sweep/manifest.json).
- [Guía del experimento](../../README.md).
- [Figuras del piloto conservadas](../marginal_pilot/README.md).
