# N=1, N=2 y N=3 con el mismo p₀

Curvas originales de 31 nodos, contrastadas con 21 nodos. ρ comunes que pasan el filtro para todos los p₀ y los 3 modelos: 0.6.

Producto 2: porcentaje de las ventas propias. Outside: porcentaje de períodos sin venta de ningún seller. Beneficios por seller; valores descontados del juego real.

El OE marginal conserva la distribución conjunta de los rivales. No se supone independencia entre rivales.

**Comparación principal: producto 2 al pasar de uno a dos y tres sellers:** [PNG](05_product2_by_seller_count.png) · [PDF](05_product2_by_seller_count.pdf). Cada curva mantiene p₀ fijo; las filas separan ρ. Se comparan monopolio y OE marginal con dos y tres sellers.

| p₀ | Políticas | Producto 2 | Beneficios | Outside |
|---|---|---|---|---|
| 0.1 | [PNG](p0_0p1/01_policy_comparison.png) · [PDF](p0_0p1/01_policy_comparison.pdf) | [PNG](p0_0p1/02_product2_usage_comparison.png) · [PDF](p0_0p1/02_product2_usage_comparison.pdf) | [PNG](p0_0p1/03_profit_comparison.png) · [PDF](p0_0p1/03_profit_comparison.pdf) | [PNG](p0_0p1/04_outside_option_comparison.png) · [PDF](p0_0p1/04_outside_option_comparison.pdf) |
| 0.5 | [PNG](p0_0p5/01_policy_comparison.png) · [PDF](p0_0p5/01_policy_comparison.pdf) | [PNG](p0_0p5/02_product2_usage_comparison.png) · [PDF](p0_0p5/02_product2_usage_comparison.pdf) | [PNG](p0_0p5/03_profit_comparison.png) · [PDF](p0_0p5/03_profit_comparison.pdf) | [PNG](p0_0p5/04_outside_option_comparison.png) · [PDF](p0_0p5/04_outside_option_comparison.pdf) |
| 0.8 | [PNG](p0_0p8/01_policy_comparison.png) · [PDF](p0_0p8/01_policy_comparison.pdf) | [PNG](p0_0p8/02_product2_usage_comparison.png) · [PDF](p0_0p8/02_product2_usage_comparison.pdf) | [PNG](p0_0p8/03_profit_comparison.png) · [PDF](p0_0p8/03_profit_comparison.pdf) | [PNG](p0_0p8/04_outside_option_comparison.png) · [PDF](p0_0p8/04_outside_option_comparison.pdf) |

Filtro: máximo 5 puntos porcentuales en probabilidades y 5% relativo simétrico en beneficios/valores. Es evidencia finita; no demuestra convergencia continua ni unicidad.
