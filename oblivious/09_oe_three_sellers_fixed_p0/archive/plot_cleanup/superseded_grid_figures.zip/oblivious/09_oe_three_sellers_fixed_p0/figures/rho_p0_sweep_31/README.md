# Uno, dos y tres sellers: OE marginal con p₀ fijo

**La estabilidad se comprueba por caso y por métrica.** Cada comparación N=1,2,3 usa la misma grilla dentro de un (p₀,ρ); otros casos pueden usar otra grilla. Se contrastan las dos grillas comunes certificadas más finas de cada caso.

Los puntos que no pasan el filtro de su métrica se omiten y aparecen como gaps. Un beneficio estacionario sensible a la grilla no invalida automáticamente un punto de producto 2 estable.

**Comparación principal:** [PNG](05_product2_by_seller_count.png) · [PDF](05_product2_by_seller_count.pdf). Cada curva mantiene p₀ fijo al cambiar N.

Producto 2: porcentaje de ventas propias. Outside: períodos sin ventas en todo el mercado. Beneficios por seller; valor inicial descontado del juego real. Las políticas son soluciones certificadas en nodos originales; no se demuestra estabilidad puntual de sus umbrales.

| p₀ | Políticas | Producto 2 | Beneficios | Outside |
|---|---|---|---|---|
| 0.1 | [PNG](p0_0p1/01_policy_comparison.png) · [PDF](p0_0p1/01_policy_comparison.pdf) | [PNG](p0_0p1/02_product2_usage_comparison.png) · [PDF](p0_0p1/02_product2_usage_comparison.pdf) | [PNG](p0_0p1/03_profit_comparison.png) · [PDF](p0_0p1/03_profit_comparison.pdf) | [PNG](p0_0p1/04_outside_option_comparison.png) · [PDF](p0_0p1/04_outside_option_comparison.pdf) |
| 0.3 | [PNG](p0_0p3/01_policy_comparison.png) · [PDF](p0_0p3/01_policy_comparison.pdf) | [PNG](p0_0p3/02_product2_usage_comparison.png) · [PDF](p0_0p3/02_product2_usage_comparison.pdf) | [PNG](p0_0p3/03_profit_comparison.png) · [PDF](p0_0p3/03_profit_comparison.pdf) | [PNG](p0_0p3/04_outside_option_comparison.png) · [PDF](p0_0p3/04_outside_option_comparison.pdf) |
| 0.5 | [PNG](p0_0p5/01_policy_comparison.png) · [PDF](p0_0p5/01_policy_comparison.pdf) | [PNG](p0_0p5/02_product2_usage_comparison.png) · [PDF](p0_0p5/02_product2_usage_comparison.pdf) | [PNG](p0_0p5/03_profit_comparison.png) · [PDF](p0_0p5/03_profit_comparison.pdf) | [PNG](p0_0p5/04_outside_option_comparison.png) · [PDF](p0_0p5/04_outside_option_comparison.pdf) |
| 0.7 | [PNG](p0_0p7/01_policy_comparison.png) · [PDF](p0_0p7/01_policy_comparison.pdf) | [PNG](p0_0p7/02_product2_usage_comparison.png) · [PDF](p0_0p7/02_product2_usage_comparison.pdf) | [PNG](p0_0p7/03_profit_comparison.png) · [PDF](p0_0p7/03_profit_comparison.pdf) | [PNG](p0_0p7/04_outside_option_comparison.png) · [PDF](p0_0p7/04_outside_option_comparison.pdf) |
| 0.8 | [PNG](p0_0p8/01_policy_comparison.png) · [PDF](p0_0p8/01_policy_comparison.pdf) | [PNG](p0_0p8/02_product2_usage_comparison.png) · [PDF](p0_0p8/02_product2_usage_comparison.pdf) | [PNG](p0_0p8/03_profit_comparison.png) · [PDF](p0_0p8/03_profit_comparison.pdf) | [PNG](p0_0p8/04_outside_option_comparison.png) · [PDF](p0_0p8/04_outside_option_comparison.pdf) |
| 0.9 | [PNG](p0_0p9/01_policy_comparison.png) · [PDF](p0_0p9/01_policy_comparison.pdf) | [PNG](p0_0p9/02_product2_usage_comparison.png) · [PDF](p0_0p9/02_product2_usage_comparison.pdf) | [PNG](p0_0p9/03_profit_comparison.png) · [PDF](p0_0p9/03_profit_comparison.pdf) | [PNG](p0_0p9/04_outside_option_comparison.png) · [PDF](p0_0p9/04_outside_option_comparison.pdf) |

Cada casilla indica el cambio máximo entre N=1,2,3: probabilidades en puntos porcentuales; beneficio/valor en porcentaje relativo simétrico. ✓ pasa el límite de 5; ✗ se omite.

| p₀ | ρ | Grillas | Producto 2 | Outside | Beneficio | Valor inicial |
|---|---|---|---|---|---|---|
| 0.1 | 0.6 | 21 → 31 | ✓ 0.684 | ✓ 0.0546 | ✓ 0.497 | ✓ 0.492 |
| 0.1 | 0.7 | 21 → 31 | ✓ 0.727 | ✓ 0.102 | ✓ 0.53 | ✓ 0.517 |
| 0.1 | 0.8 | 21 → 31 | ✓ 1.06 | ✓ 0.363 | ✓ 1.11 | ✓ 1.4 |
| 0.1 | 0.9 | 21 → 31 | ✓ 3.95 | ✓ 0.21 | ✓ 3.94 | ✓ 4.64 |
| 0.3 | 0.6 | 21 → 31 | ✓ 2.64 | ✓ 0.615 | ✓ 1.41 | ✓ 1.4 |
| 0.3 | 0.7 | 21 → 31 | ✓ 2.34 | ✓ 0.54 | ✓ 1.33 | ✓ 1.35 |
| 0.3 | 0.8 | 21 → 31 | ✗ 5.05 | ✓ 1.67 | ✗ 5.28 | ✗ 5.92 |
| 0.3 | 0.9 | 21 → 31 | ✓ 3.95 | ✓ 1.1 | ✓ 3.9 | ✓ 4.61 |
| 0.5 | 0.6 | 21 → 31 | ✓ 1.17 | ✓ 0.318 | ✓ 0.724 | ✓ 0.717 |
| 0.5 | 0.7 | 21 → 31 | ✓ 3.3 | ✓ 1.63 | ✓ 1.16 | ✓ 1.88 |
| 0.5 | 0.8 | 21 → 31 | ✓ 3.32 | ✓ 0.636 | ✓ 3.11 | ✓ 3.49 |
| 0.5 | 0.9 | 21 → 31 | ✓ 1.81 | ✓ 0.846 | ✓ 2.19 | ✓ 2.19 |
| 0.7 | 0.6 | 21 → 31 | ✓ 0.33 | ✓ 0.318 | ✓ 0.406 | ✓ 0.158 |
| 0.7 | 0.7 | 21 → 31 | ✓ 0.959 | ✓ 0.366 | ✓ 0.588 | ✓ 0.655 |
| 0.7 | 0.8 | 21 → 31 | ✓ 1.1 | ✓ 0.307 | ✓ 1.1 | ✓ 0.822 |
| 0.7 | 0.9 | 21 → 31 | ✓ 0.238 | ✗ 19.4 | ✗ 34.4 | ✓ 1.58 |
| 0.8 | 0.6 | 21 → 31 | ✓ 3.41 | ✓ 1.61 | ✓ 1.55 | ✓ 0.693 |
| 0.8 | 0.7 | 21 → 31 | ✓ 0.974 | ✓ 0.778 | ✓ 1.43 | ✓ 0.177 |
| 0.8 | 0.8 | 21 → 31 | ✓ 0.924 | ✓ 3.86 | ✗ 16.1 | ✓ 0.303 |
| 0.8 | 0.9 | 21 → 31 | ✗ 6.36 | ✓ 0.00496 | ✗ 30.6 | ✓ 1.5 |
| 0.9 | 0.6 | 21 → 31 | ✓ 3.58 | ✓ 0.0466 | ✓ 4.51 | ✓ 0.00884 |
| 0.9 | 0.7 | 21 → 31 | ✓ 0.779 | ✓ 0.00702 | ✓ 3.85 | ✓ 0.0617 |
| 0.9 | 0.8 | 21 → 31 | ✓ 0.263 | ✓ 0.00148 | ✗ 12.3 | ✓ 0.0566 |
| 0.9 | 0.9 | 21 → 31 | ✓ 0 | ✓ 2.34e-06 | ✗ 60 | ✓ 0.126 |

Detalles: [contrastes por modelo](../../data/rho_p0_sweep_31/expanded_grid_stability.csv) · [retención por métrica](../../data/rho_p0_sweep_31/metric_retention.json).

OE marginal conserva la distribución conjunta de los rivales; no supone independencia iid. La auditoría independiente verifica los resultados guardados. Los contrastes entre grillas son evidencia local finita y no prueban convergencia continua, unicidad ni equilibrio Markov perfecto.
