# Plot 05 con referencia del monopolio

[PNG](05_product2_by_seller_count.png) · [PDF](05_product2_by_seller_count.pdf)

Cada color identifica un p₀. La curva continua compara N=1,2,3; la línea horizontal discontinua mantiene el uso del producto 2 del monopolio (N=1) con ese mismo p₀ y ρ. Si ambas coinciden, se superponen. El eje vertical mide el porcentaje de ventas propias con producto 2.

Se conservan exactamente los casos y las grillas del reporte original: 21 → 31, con 22 de 24 pares validados para producto 2. Se omiten (p₀,ρ)=(0.3,0.8) y (0.8,0.9), incluidas sus referencias.

Los datos, el reporte y las figuras anteriores se conservan sin cambios. No se vuelve a resolver ningún modelo.
