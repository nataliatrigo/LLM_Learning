# Uno, dos y tres sellers con outside fijo

Este experimento agrega un tercer seller estratégico al modelo de
[outside fijo](../08_oe_distribution_fixed_p0/README.md). Compara monopolio,
OE marginal con dos y tres sellers. Por indicación del usuario, la comparación
actual se limita a distribución marginal.
Cada modelo resuelve sus propias políticas y distribución estacionaria con
la misma economía. El barrido 201/251 del experimento 08 sigue pausado.

La ampliación actual usa `rho = {0.6, 0.7, 0.8, 0.9}` y
`p0 = {0.1, 0.3, 0.5, 0.7, 0.8, 0.9}`. El refinamiento completo usa 41 puntos
para `p0=0.7,0.8,0.9`, contrastados con 31; los p0 menores conservan 31,
contrastados con 21. Su manifiesto está en
[data/high_p0_refinement_41](data/high_p0_refinement_41/manifest.json), y sus figuras
en [figures/high_p0_refinement_41](figures/high_p0_refinement_41/README.md).
El [plot 05 con referencia del monopolio](figures/high_p0_refinement_41/05_product2_by_seller_count.png)
añade líneas horizontales discontinuas por p0 y rho.
El [barrido inicial 21/31](figures/rho_p0_sweep_31/README.md) y su
[versión con referencias](figures/rho_p0_sweep_31_monopoly_reference/README.md) se conservan.
Los resultados y las figuras del piloto se conservan.

El piloto marginal usa `p0 = {0.1, 0.5, 0.8}`, `rho = {0.6, 0.8}` y grillas comunes
de 21 y 31 puntos. Se conserva cada resultado certificado antes de continuar.
Solo se publican comparaciones que pasan los controles de grilla en todos los
modelos y todos los p0 incluidos. Una ampliación de la grilla queda documentada
en el manifiesto; no modifica los resultados anteriores.

## Elecciones del comprador y evolución del juego

La publicación [choice_dynamics_41](figures/choice_dynamics_41/README.md)
usa las políticas ya certificadas del refinamiento, sin resolver nuevos
equilibrios:

- [Frecuencias de elección](figures/choice_dynamics_41/01_stationary_buyer_choices.png):
  barras de A/B/C/outside que suman 100% de los períodos, para uno, dos y tres
  sellers. Se muestran 23 de los 24 pares p0/rho con el filtro de estabilidad
  de outside; se omite `p0=.7,rho=.9`.
- [Evolución promedio](figures/choice_dynamics_41/02_expected_evolution.png):
  probabilidades de elegir a cada seller, reputaciones esperadas y ventas
  acumuladas esperadas, propagando exactamente la ley conjunta del juego finito.
- Trayectorias aleatorias para
  [p0=.5](figures/choice_dynamics_41/03_sample_path_p0_0p5.png) y
  [p0=.8](figures/choice_dynamics_41/03_sample_path_p0_0p8.png): reputaciones,
  seller elegido, producto entregado y ventas acumuladas de cada identidad.

Las trayectorias usan `rho=.6`, 600 períodos y reputaciones iniciales `.5`;
las grillas son 31 para p0=.5 y 41 para p0=.8. Las políticas permanecen fijas.
Solo se actualiza el seller que vende y se usa la misma lotería de interpolación
del kernel; outside congela todas las reputaciones. La simetría iguala las
frecuencias estacionarias de A/B/C, pero una realización puede tener rachas
distintas. Los transitorios son ilustraciones del juego certificado en su
grilla; no tienen un contraste propio de estabilidad entre grillas.
Los [datos y manifiesto](data/choice_dynamics_41/manifest.json) guardan semillas,
cuentas, trayectorias, expectativas y hashes. Siete tests contrastan la simulación
con el kernel y comprueban las actualizaciones y la propagación de probabilidades.

## Modelo

Se mantienen `R=1`, `c1=0.05`, `c2=0.65`, `p1=0.35`, `p2=0.80`,
`gamma=0.98`. El comprador sortea una valoración Beta independiente por
seller, condicionada en sus reputaciones. Compra al mayor sorteo si supera
al outside conocido `p0`. Para tres sellers:

```text
D_A(x,y,z;p0) = integral_{p0}^1 f_x(t) F_y(t) F_z(t) dt
D_out(x,y,z)  = F_x(p0) F_y(p0) F_z(p0)
D_A + D_B + D_C + D_out = 1
```

El seller seleccionado decide qué producto entregar. Su reputación cambia a
`rho*x + 1-rho` con éxito y a `rho*x` con fracaso. Las reputaciones de los
otros sellers quedan fijas. Si gana el outside, ninguna cambia. La política
es simétrica y depende solo de la reputación propia: `alpha(x)`.

La ley conjunta real en tiempo calendario es `nu(x,y,z)`. En OE marginal, el
seller usa la distribución **conjunta** de los otros dos:

```text
R_BC(y,z) = sum_x nu(x,y,z)
d_marginal(x) = sum_yz D_A(x,y,z;p0) R_BC(y,z)
```

No se sustituye esa conjunta por un producto de marginales independientes.
El Bellman unidimensional incluye los períodos sin venta y el
descuento; el punto fijo vuelve a resolver la ley conjunta y la política.
Esto es un equilibrio oblivious, no un equilibrio de información completa.

## Validación y métricas

La cuadratura de demanda se contrasta con orden doblado y con integrales
adaptativas independientes en los tests. La simetría permite agrupar
exactamente los estados que difieren solo en la identidad de los sellers;
se comprueba esa reducción contra todas las filas del kernel completo.

La ley estacionaria usa tasas de salida calculadas sumando flujos positivos,
evitando restar probabilidades casi iguales a uno. Se comprueban métodos y
órdenes independientes, positividad, normalización e invariancia de flujos.
Las cadenas pequeñas incluyen eliminación positiva GTH en ambos órdenes;
las grandes requieren además iteraciones positivas desde dos distribuciones
iniciales. Agotar un presupuesto de comprobación produce un fallo explícito.
En el cierre condicional se comparan también todas las filas positivas por
separado. No se descartan probabilidades pequeñas mediante un umbral de masa.

Las figuras comparan:

- Política de producto 2 según reputación propia.
- Producto 2 como porcentaje de las **ventas propias**.
- Beneficio por seller y período, y valor descontado real desde reputaciones
  iniciales `0.5` para todos los sellers.
- Outside como porcentaje de los períodos de todo el mercado: `1 - N*sale_rate`.

Se contrasta la ley de reputación por venta propia con una cadena independiente
unidimensional. El valor descontado se evalúa en el juego conjunto real,
separado del valor percibido del Bellman OE. Las comparaciones entre grillas
admiten como máximo 5 puntos porcentuales en probabilidades y 5% de diferencia
relativa simétrica en beneficios y valor. Estos controles no prueban
convergencia al continuo, unicidad ni estabilidad exacta de los umbrales.

## Comparación inicial

La comparación que pasa los controles comunes de grilla usa `rho=0.6`, con
curvas originales de 31 puntos contrastadas con 21. Uso de producto 2 entre
ventas propias, en porcentaje:

| p0 | Monopolio | Dos sellers, OE marginal | Tres sellers, OE marginal |
| --- | ---: | ---: | ---: |
| 0.1 | 0.00 | 15.97 | 41.46 |
| 0.5 | 44.09 | 49.00 | 51.02 |
| 0.8 | 75.65 | 75.65 | 75.65 |

Estos números muestran que agregar un seller no reduce siempre el uso del
producto 2. La igualdad del último renglón corresponde a este piloto finito;
no garantiza igualdad de las políticas o de los umbrales en grillas superiores.

Los resultados de `rho=0.8` se conservan en los datos y se excluyen de las figuras
estables. En `p0=0.8`, el beneficio de dos sellers cambia aproximadamente 16%
entre las grillas de 21 y 31, por encima del límite de 5%.

El [plot principal](figures/marginal_pilot/05_product2_by_seller_count.png)
compara directamente uno, dos y tres sellers. El
[índice de figuras](figures/marginal_pilot/README.md) enlaza las políticas,
el uso de producto 2, los beneficios y el outside.

## Ejecución

Desde la raíz del repositorio:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 .venv/bin/python -B -m oblivious.oe_three_sellers_fixed_p0.code.marginal_entry
MPLCONFIGDIR=/tmp/three-seller-mpl .venv/bin/python -B -m oblivious.oe_three_sellers_fixed_p0.code.report
```

Para retomar una campaña interrumpida se usa `--resume`. Las fuentes, las
configuraciones y los checkpoints deben coincidir con sus SHA-256. Una
ampliación explícita usa, por ejemplo, `--resume --extend-grids --grids 21 31 51`.
El último caso marginal necesitó ampliar el presupuesto de iteración positiva
independiente, conservando el algoritmo y todas las tolerancias:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 .venv/bin/python -B -m oblivious.oe_three_sellers_fixed_p0.code.validation_entry --resume
```

Esta continuación conserva el manifiesto del intento anterior y los checkpoints
ya certificados, y registra las fuentes y presupuestos de la nueva fase.

## Barrido ampliado de rho y p0

El barrido nuevo compara los tres tamaños de mercado en los 24 pares `(p0,rho)`.
Usa inicialmente grillas de 21 y 31 puntos: 144 resultados modelo/grilla,
incluidos los 36 checkpoints importados byte a byte del piloto. Tres workers
independientes resuelven pares diferentes; cada resultado se guarda antes de
continuar. Solo el proceso principal actualiza el manifiesto y los CSV comunes.

Los 144 resultados están calculados y pasan la auditoría independiente de las
ecuaciones y los datos guardados. El contraste entre 21 y 31 conserva 22 de los
24 pares para producto 2, 23 para outside, 18 para beneficio estacionario y 23
para valor inicial. Esta validación local no implica convergencia al continuo.
El [plot principal del barrido](figures/rho_p0_sweep_31_monopoly_reference/05_product2_by_seller_count.png)
compara directamente los tres tamaños de mercado para cada p0 y rho. Sus líneas
horizontales discontinuas muestran el monopolio con los mismos parámetros; se
superponen a la curva continua cuando el uso del producto 2 coincide.
La [versión inicial](figures/rho_p0_sweep_31/05_product2_by_seller_count.png) se conserva.

La búsqueda usa las mismas ecuaciones con una factorización dispersa más rápida
y derivadas analíticas bajo demanda. El certificado final mantiene las
tolerancias originales y contrasta dos soluciones dispersas con eliminación
positiva en ambos órdenes. Las matrices densas de referencia pasan por un
control de memoria compartido entre procesos.

Los nuevos gráficos comprueban cada métrica por separado, usando para cada par
las dos grillas más finas certificadas comunes a monopolio, dos y tres sellers.
Producto 2 y outside admiten hasta 5 puntos porcentuales; beneficios y valor,
hasta 5% relativo simétrico. Si algún modelo falla el control de una métrica,
se omite esa comparación completa de tres modelos, conservándola en los datos.
Las líneas dejan huecos en los casos omitidos. La tabla de sensibilidad y el
manifiesto del reporte identifican los puntos incluidos y excluidos de cada
figura. La certificación de una política finita no garantiza estabilidad exacta
de sus umbrales.

```bash
MPLCONFIGDIR=/tmp/three-seller-mpl OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=2 .venv/bin/python -B -m oblivious.oe_three_sellers_fixed_p0.code.expanded_safe --name rho_p0_sweep_31 --grids 21 31 --workers 3
MPLCONFIGDIR=/tmp/three-seller-mpl OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 .venv/bin/python -B -m oblivious.oe_three_sellers_fixed_p0.code.expanded_finish --name rho_p0_sweep_31
```

Para retomar el barrido se añade `--resume` al primer comando. Un refinamiento
selectivo conserva las grillas anteriores y añade al primer comando, por ejemplo,
`--resume --add-case-grid 0.8:0.8:41 --workers 1`. Las figuras solo se publican
cuando el barrido y su auditoría independiente están cerrados y sus hashes
coinciden.

La primera validación global de 41 puntos se detuvo por su costo computacional;
sus 57 resultados certificados se conservan por separado en
[data/rho_p0_sweep](data/rho_p0_sweep/manifest.json). No se presenta ese conjunto
parcial como un barrido terminado ni se mezcla con las curvas iniciales.
Los datos del barrido ampliado quedan en
[data/rho_p0_sweep_31](data/rho_p0_sweep_31/manifest.json), y su índice de figuras
se genera en [figures/rho_p0_sweep_31](figures/rho_p0_sweep_31/README.md).
El piloto se conserva en [data/marginal_pilot](data/marginal_pilot/manifest.json).

### Refinamiento de los p0 altos

La campaña separada `high_p0_refinement_41` conserva byte a byte los 144
resultados del barrido completo y añade una grilla de 41 puntos a `p0=0.7,0.8,0.9`
para los cuatro rho y los tres tamaños de mercado: 36 cálculos nuevos.
Los p0 menores conservan las grillas 21/31. El objetivo es comprobar si las
políticas y las proporciones de producto 2 que coincidían en 31 puntos siguen
coincidiendo con más resolución.

Los 180 resultados pasaron la auditoría independiente. El reporte conserva
22 de los 24 pares para producto 2, 23 para outside, 19 para beneficio
estacionario y 23 para valor inicial. Los puntos que fallan cada contraste
se omiten de su métrica. Para producto 2 se omiten `(p0,rho)=(0.3,0.8)` y
`(0.8,0.9)`, con cambios máximos de 5.05 y 7.38 puntos porcentuales.

La igualdad no se mantiene en todos los refinamientos. Por ejemplo, para
`p0=0.8,rho=0.6`, producto 2 como porcentaje de ventas propias:

| Grilla | Monopolio | Dos sellers | Tres sellers |
| --- | ---: | ---: | ---: |
| 31 | 75.65% | 75.65% | 75.65% |
| 41 | 77.16% | 74.05% | 74.05% |

El [plot 05 refinado](figures/high_p0_refinement_41/05_product2_by_seller_count.png)
y el [índice completo](figures/high_p0_refinement_41/README.md) muestran los
resultados. Estos contrastes finitos no demuestran convergencia al continuo
ni estabilidad exacta de los umbrales.

Las ecuaciones y las tolerancias se mantienen. Las dos soluciones dispersas
independientes usan una ordenación de matriz más rápida. Para `rho=0.6,0.7`,
se contrastan además con iteraciones positivas desde dos leyes iniciales;
para `rho=0.8,0.9`, con eliminación positiva GTH en ambos órdenes. Los presupuestos
y las fuentes se registran en el manifiesto. Agotar un control produce un fallo
explícito. La auditoría y las figuras se generan al terminar el conjunto completo,
sin modificar publicaciones anteriores.

```bash
MPLCONFIGDIR=/tmp/highp0-mpl OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=2 .venv/bin/python -B -m oblivious.oe_three_sellers_fixed_p0.code.high_p0_refine --workers 3
MPLCONFIGDIR=/tmp/highp0-mpl OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 .venv/bin/python -B -m oblivious.oe_three_sellers_fixed_p0.code.high_p0_finish --name high_p0_refinement_41 --poll 20 --expected-count 180
```

Para reanudar una ejecución interrumpida de la fase inicial, se añade `--resume`
al primer comando. Los nuevos datos
se guardan en `data/high_p0_refinement_41`; las figuras están en
`figures/high_p0_refinement_41`. El plot 05 mantiene las referencias horizontales
del monopolio. Se documentan por separado la igualdad de políticas en los nodos
y la estabilidad entre grillas de cada métrica.

El último caso, tres sellers con `p0=0.8,rho=0.8,n=41`, usa la continuación
`high_p0_lower_face_recovery`. Esta fase conserva los 179 resultados previos y
registra sus fuentes y snapshots. Inicia la búsqueda de mezcla en `x=0.325`,
con producto 2 en `x=0.875` como semilla. Calcula solo las columnas necesarias
del Jacobiano, comprueba los incentivos de todos los nodos y amplía el conjunto
activo si hace falta. La solución debe pasar el certificado completo original.
Los intentos previos quedan registrados en el manifiesto. Si esta continuación
se interrumpe con ese único caso pendiente, se reanuda con:

```bash
MPLCONFIGDIR=/tmp/highp0-mpl OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=2 .venv/bin/python -B -m oblivious.oe_three_sellers_fixed_p0.code.high_p0_lower_face_recovery --resume
```

La campaña inicial `data/pilot` conserva sus resultados certificados, incluidos
los condicionales. La campaña marginal importa byte a byte únicamente los
checkpoints de monopolio y OE marginal; sus manifiestos registran las fuentes,
las huellas y el cambio de alcance. El control condicional que detuvo la campaña
inicial no se presenta como un resultado certificado ni se usa en la comparación
actual.

Los tests del nuevo modelo incluyen reducción por simetría, Jacobianos contra
diferencias finitas, equivalencia con el modelo histórico de dos sellers,
correlación de los rivales, filas condicionales de masa `1e-200` y evaluación
de los beneficios descontados contra una solución lineal independiente.
